// config.js
const CONFIG = {
  API_URL: "http://localhost:5000",
  AUTH_KEY: "saferoute_token",
  GOOGLE_MAPS_API_KEY: "AIzaSyAebd8duQVQT7TL9lL29FJaXef4IfZTtnI"
};
